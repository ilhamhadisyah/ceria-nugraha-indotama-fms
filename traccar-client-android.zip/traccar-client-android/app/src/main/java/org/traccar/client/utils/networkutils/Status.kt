package org.traccar.client.utils.networkutils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}