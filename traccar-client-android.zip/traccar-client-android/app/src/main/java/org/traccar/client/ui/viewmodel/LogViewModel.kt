package org.traccar.client.ui.viewmodel

import androidx.lifecycle.ViewModel

class LogViewModel : ViewModel(){

    fun getActivityLog(){

    }

}